# WebCraft — Web Development Activity-Based Learning Project

This project implements **three case studies** from the provided Web Development Activity-Based Learning task sheet:

1. **Personal Portfolio Website** (`portfolio.html`)
2. **College Information and Admissions Website** (`college.html`)
3. **Online Learning Platform Interface** (`learning.html`)

The project landing page is `index.html`.

## Technologies

- HTML5 for semantic page structure
- CSS3 for responsive layouts, cards, transitions, and visual styling
- Vanilla JavaScript for mobile navigation, contact-form feedback, course searching, category filtering, and enrollment demo feedback

## How to run

1. Extract the ZIP file.
2. Open the `webdev_abl_project` folder in Visual Studio Code.
3. Open `index.html` in your browser, or use the **Live Server** extension in VS Code.
4. Use the top navigation to visit the three case studies.

No package installation or build process is required. Google Fonts are loaded from the internet when available; the site uses fallback fonts if they are not.

## Folder structure

```text
webdev_abl_project/
├── index.html
├── portfolio.html
├── college.html
├── learning.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── main.js
```

## Features checklist

- [x] Three separate case-study webpages and a project home page
- [x] Responsive navigation and mobile menu
- [x] Personal profile, education, skills, hobbies, project examples, achievements, and contact form
- [x] College overview, departments/programs, campus facilities, admissions steps, and contact details
- [x] Course categories, course cards, instructor profiles, learning objectives, search, category filters, and enrollment buttons
- [x] CSS hover effects, progress bars, responsive grids, and reduced-motion support
- [x] Form labels, required fields, accessible button labels, and status feedback

## Important notes before submission

- The college name **Northstar Institute**, sample email addresses, course details, ratings, and campus figures are illustrative placeholders for a demonstration, not verified real-world information.
- The portfolio uses the student profile details supplied for this project. Update the sample email and project entries if your faculty expects your exact details and completed work.
- The contact form and enrollment buttons demonstrate front-end interactions only. They do not send messages, create accounts, or save enrollment records because no backend is included.
- If your faculty specifies a particular college name, logo, screenshots, or extra case-study requirements, update the corresponding HTML before submission.

## Suggested GitHub repository description

`Responsive Web Development ABL project featuring a personal portfolio, college information and admissions website, and online learning platform built with HTML, CSS, and JavaScript.`
