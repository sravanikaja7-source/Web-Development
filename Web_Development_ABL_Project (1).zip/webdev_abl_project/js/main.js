'use strict';

// Mobile navigation shared by all pages.
document.querySelectorAll('.menu-toggle').forEach((toggle) => {
  const nav = toggle.parentElement.querySelector('.nav-links');
  if (!nav) return;
  toggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    toggle.textContent = isOpen ? '✕' : '☰';
  });
  nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.textContent = '☰';
  }));
});

// Portfolio contact form: validate and show a local demo response only.
const contactForm = document.querySelector('#contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!contactForm.reportValidity()) return;
    const feedback = contactForm.querySelector('.form-feedback');
    feedback.textContent = 'Thanks! This demo form works locally, but it does not send or store your message.';
    contactForm.reset();
  });
}

// Learning page: search and category filtering can be combined.
const courseGrid = document.querySelector('#course-grid');
if (courseGrid) {
  const searchInput = document.querySelector('#course-search');
  const filterButtons = [...document.querySelectorAll('.filter-btn')];
  const courseCards = [...courseGrid.querySelectorAll('.course-card')];
  const emptyState = document.querySelector('#empty-state');
  const feedback = document.querySelector('#enroll-feedback');
  let activeFilter = 'All';

  function filterCourses() {
    const term = searchInput.value.trim().toLowerCase();
    let visibleCount = 0;
    courseCards.forEach((card) => {
      const matchesCategory = activeFilter === 'All' || card.dataset.category === activeFilter;
      const searchable = `${card.dataset.search} ${card.textContent}`.toLowerCase();
      const matchesSearch = searchable.includes(term);
      const visible = matchesCategory && matchesSearch;
      card.hidden = !visible;
      if (visible) visibleCount += 1;
    });
    emptyState.hidden = visibleCount !== 0;
  }

  searchInput.addEventListener('input', filterCourses);
  filterButtons.forEach((button) => button.addEventListener('click', () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach((item) => {
      const selected = item === button;
      item.classList.toggle('active', selected);
      item.setAttribute('aria-pressed', String(selected));
    });
    filterCourses();
  }));
  document.querySelectorAll('.enroll-btn').forEach((button) => button.addEventListener('click', () => {
    feedback.textContent = `You selected “${button.dataset.course}”. This is a front-end demo; real enrollment needs a backend.`;
  }));
  filterCourses();
}
